const s="/assets/image-8-5qLO7jx6.png",a="/assets/image-10-y51NboIF.png";export{a,s as i};
