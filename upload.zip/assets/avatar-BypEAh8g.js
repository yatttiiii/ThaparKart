const a="/assets/avatar-C5P7lt0q.svg";export{a};
