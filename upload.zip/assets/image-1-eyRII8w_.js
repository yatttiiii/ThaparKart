const s="/assets/image-1-BQchIydS.png";export{s as i};
