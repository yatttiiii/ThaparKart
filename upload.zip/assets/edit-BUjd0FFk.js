const s="/assets/edit-DfJSBYxT.svg";export{s as e};
